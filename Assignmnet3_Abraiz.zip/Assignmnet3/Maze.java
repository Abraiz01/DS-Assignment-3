import java.util.Random;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.ArrayList;

public class Maze {

    private final int WIDTH;
    private final int LENGTH;
    private Node[][] maze;
    // starting node for prims algorithm
    private Node starting_node;

    // hashmap with keys as Nodes and values as lists storing the neighboring walls not broken yet
    private Map<Node, List<Integer>> mapOfWalls = new HashMap<>();
    private Random rand = new Random();
    // array list storing all keys of the hashmap
    private List<Node> listOfKeys = new ArrayList<>();


    // creating constructor for the maze
    public Maze(int width, int length) {
        this.WIDTH = width;
        this.LENGTH = length;
        maze = new Node[WIDTH][LENGTH];

        createMaze();

    }

    public Node[][] getMaze() {
        return maze;
    }

    //creating maze with WIDTH*LENGTH dimensions
    public void createMaze(){
        for (int i = 0; i < WIDTH; ++i) {
            for (int j = 0; j < LENGTH; ++j) {
                maze[i][j] = new Node(i, j);
            }
        }

        // starting node for prims algorithm
        starting_node = maze[1][1];

        left_and_right_border();
        top_and_bottom_border();

        maze[0][0].setRight(false);
        maze[0][0].setBelow(false);
        maze[1][1].setLeft(false);
        maze[LENGTH - 1][WIDTH - 1].setRight(false);
        
        prims_alg(starting_node);

    }

    //creating left and right borders
    private void left_and_right_border(){
        for (int i = 1; i < WIDTH; i++) {
            maze[0][i].setLeft(false);
            maze[0][i].setRight(false);
            maze[0][i].setAbove(false);
            maze[0][i].setBelow(false);
            maze[1][i].setLeft(true);
            maze[LENGTH - 1][i].setRight(true);
        }
    }

    //creating top and bottom borders
    private void top_and_bottom_border(){
        for (int i = 1; i < LENGTH; i++) {
            maze[i][0].setLeft(false);
            maze[i][0].setAbove(false);
            maze[i][0].setRight(false);
            maze[i][0].setBelow(false);
            maze[i][1].setAbove(true);
            maze[i][WIDTH - 1].setBelow(true);
        }
    }

    private void prims_alg(Node root) {
        // creating a list for storing walls found around a node 
        List<Integer> foundWalls = wall_finder(root);
        if (foundWalls.size() > 0) {
            mapOfWalls.put(root, foundWalls); 
        }
        // creating list of nodes from mapOfWalls
        for (Node key : mapOfWalls.keySet()) {
            listOfKeys.add(key);
        }
        // Node picked at random
        int rand_int = rand.nextInt(listOfKeys.size());
        Node curr = listOfKeys.get(rand_int); 

        while (!mapOfWalls.isEmpty()) {
            
            curr.setVisited(true);

            //list of walls around curr
            List<Integer> walls = mapOfWalls.get(curr);
            // random location picked out of list 
            int location = walls.get(rand.nextInt(walls.size())); 

            // checking if neighbour Node is visited
            // neighbouring node isn't added to the mapOfWalls if it has already been visited
            if (!check_neighbor_visited(curr, location)) {
                //going to the next Node and breaking wall
                Node nextNode = break_wall(curr, location); 
                nextNode.setVisited(true);
                List<Integer> wall = wall_finder(nextNode);

                // If there is at least one neighbour and nextNode has not been visited
                if (wall.size() > 0 && !listOfKeys.contains(nextNode)) { 
                    listOfKeys.add(nextNode);
                    mapOfWalls.put(nextNode, wall);
                }

            }
            // removing wall from the list of walls
            // casting location to Integer first
            walls.remove((Integer) location);
            
            if (walls.size() == 0) { //Remove node if all walls have been checked
                mapOfWalls.remove(curr);
                listOfKeys.remove(curr);

                // while loop terminated when mapOfWalls is empty
                if (listOfKeys.size() == 0) {
                    System.out.println("Maze has been created with the following dimensions: ");
                    System.out.println("Number of rows: " + WIDTH);
                    System.out.println("Number of columns: " + LENGTH);
                    break;
                }
            }
            rand_int = rand.nextInt(listOfKeys.size());
            // restarts using a new node
            curr = listOfKeys.get(rand_int);
        }
    }


    // the following method returns a boolean which indicates whether the node has been visited or not
    private boolean check_neighbor_visited(Node curr, int location) {
        if (location == 0) {
            return maze[curr.get_x_index() - 1][curr.get_y_index()].getVisited();
        } else if (location == 1) {
            return maze[curr.get_x_index()][curr.get_y_index() - 1].getVisited();
        } else if (location == 2) {
            return maze[curr.get_x_index() + 1][curr.get_y_index()].getVisited();
        } else if (location == 3) {
            return maze[curr.get_x_index()][curr.get_y_index() + 1].getVisited();
        }
        return true;
    }


    private List<Integer> wall_finder(Node curr) {
        List<Integer> walls = new ArrayList<>();
        if (curr != null) {
            Node[] n = get_neighbors(curr.get_x_index(), curr.get_y_index());
            // the following block of code finds the neighboring walls that have not been broken down
            if (n[0] != null) {
                walls.add(0); 
            }
            if (n[1] != null) {
                walls.add(1); 
            }
            if (n[2] != null) {
                walls.add(2); 
            }
            if (n[3] != null) {
                walls.add(3); 
            }
        }
        return walls;
    }

    // this method breaks down the walls depending on the location and hence it creates a pathway
    private Node break_wall(Node curr, int location) {
        if (curr != null) {
            if (location == 0) { 
                curr.setLeft(false);
                maze[curr.get_x_index() - 1][curr.get_y_index()].setRight(false);
                return maze[curr.get_x_index() - 1][curr.get_y_index()];
            } else if (location == 1) { 
                curr.setAbove(false);
                maze[curr.get_x_index()][curr.get_y_index() - 1].setBelow(false);
                return maze[curr.get_x_index()][curr.get_y_index() - 1];
            } else if (location == 2) { 
                curr.setRight(false);
                maze[curr.get_x_index() + 1][curr.get_y_index()].setLeft(false);
                return maze[curr.get_x_index() + 1][curr.get_y_index()];
            } else if (location == 3) { 
                curr.setBelow(false);
                maze[curr.get_x_index()][curr.get_y_index() + 1].setAbove(false);
                return maze[curr.get_x_index()][curr.get_y_index() + 1];
            }
            curr.setVisited(true);
        }
        return null;
    }

    // finding neighbors which are not visited for prim's algorithm
    private Node[] get_neighbors(int x, int y) {
        Node[] neighbors = new Node[4];
        if (!((x-1) < 1) && !maze[x-1][y].getVisited()) {
            neighbors[0] = maze[x-1][y];
        }
        if (!((y-1) < 1) && !maze[x][y-1].getVisited()) {
            neighbors[1] = maze[x][y-1];
        }
        if (!((x+1) > (WIDTH-1)) && !maze[x+1][y].getVisited()) {
            neighbors[2] = maze[x+1][y];
        }
        if (!((y+1) > (LENGTH-1)) && !maze[x][y+1].getVisited()) {
            neighbors[3] = maze[x][y+1];
        }
        return neighbors;
    }
 

    public static void main(String[] args){
        Maze prim_maze = new Maze(5, 5);
    }
}