public class Node {

    // in the declarations below:
    // the value true which is a boolean indicates that a wall exists in that location
    // the value false whuch is a boolean indicates that a wall does not exist in that location
    private boolean left;
    private boolean above;
    private boolean right;
    private boolean below;
    private boolean visited;

    // x and y represents the location of the node in the maze
    private int x;
    private int y;

    public Node(int x, int y) {
        left = true;
        above = true;
        right = true;
        below = true;
        visited = false;
        this.x = x;
        this.y = y;
    }

    public int get_x_index() {return x;}

    public int get_y_index() {return y;}

    // underneath can be found getter and setter methods for the walls
    public void setAbove(boolean b) {above = b;}

    public void setBelow(boolean b) {below = b;}

    public void setLeft(boolean b) {left = b;}

    public void setRight(boolean b) {right = b;}

    public boolean getAbove() {return above;}

    public boolean getBelow() {return below;}

    public boolean getRight() {return right;}

    public boolean getLeft() {return left;}

    // this method checks if the node has been visited 
    public boolean getVisited() {return visited;}

    // this method sets the visited variable to true if the node has been visited
    public void setVisited(boolean b) {visited = b;}

    public boolean equals(Node Node) {
        return (this.x == Node.get_x_index() && this.y == Node.get_y_index());
    }

}