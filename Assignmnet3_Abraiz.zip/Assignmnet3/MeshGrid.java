import java.util.Iterator;
import java.util.*;

public class MeshGrid<E> implements Iterable<E>{

	int h = 0;
	int w = 0;
	private MeshNode<E> head;

	private static class MeshNode<E> implements Position<E>{

		MeshNode<E> left;
		MeshNode<E> right;
		MeshNode<E> above;
		MeshNode<E> below;
		E element;

		public MeshNode(){

			left = null;
			right = null;
			above = null;
			below = null;
			element = null;
		}

		public MeshNode(E e, MeshNode<E> l, MeshNode<E> r, MeshNode<E> b, MeshNode<E> a){

			left = l;
			right = r;
			above = a;
			below = b;
			element = e;
		}

		public E getElement(){

			return element;
		}

		public MeshNode<E> getLeft(){return left;}
		public MeshNode<E> getRight(){return right;}
		public MeshNode<E> getAbove(){return above;}
		public MeshNode<E> getBelow(){return below;}

		public void setElement(E e){element = e;}

		public void setAbove(MeshNode<E> a){above =a;} 
		public void setBelow(MeshNode<E> b){below =b;} 
		public void setLeft(MeshNode<E> l){left =l;} 
		public void setRight(MeshNode<E> r){right =r;} 

	}

	//defining the main constructor for the Meshgrid class
	public MeshGrid(int height, int width){

		h = height;
		w = width;
		MeshNode<E> currentNode = new MeshNode<>();
		head = currentNode;
		MeshNode<E> previousNode = head;

		for (int j=0; j<h; j++){

			//if the number of rows are even
			if (j%2 == 0){

				//connecting rows horizontally
				for (int i=0; i<w-1; i++){

					currentNode = new MeshNode<>();
					previousNode.setRight(currentNode);
					currentNode.setLeft(previousNode);
					previousNode = currentNode;
				}

				if (j != h-1){
					currentNode = new MeshNode<>();
					previousNode.setBelow(currentNode);
					currentNode.setAbove(previousNode);
					previousNode = currentNode;
			    }	
			}

			//if the number of rows are odd
			else{

				//connecting rows horizontally
				for (int i=0; i<w-1; i++){

					currentNode = new MeshNode<>();
					previousNode.setLeft(currentNode);
					currentNode.setRight(previousNode);
					previousNode = currentNode;

				}

				if (j != h-1){
					currentNode = new MeshNode<>();
					previousNode.setBelow(currentNode);
					currentNode.setAbove(previousNode);
					previousNode = currentNode;
				}
			}
		}

		MeshNode<E> current1 = head;
		MeshNode<E> current2;

		for(int k=0; k<h-1; k++){

			current2 = current1;

			//if the number of rows are even
			if(k%2 == 0){

				for(int i=0; i<w-1; i++){

					current2 = current2.getRight();

				}
				current2 = current2.getBelow();

				for(int i=0; i<w-1; i++){

					current2 = current2.getLeft();

				}

				//connecting rows vertically
				for(int j=0; j<w-1; j++){

					current1.setBelow(current2);
					current2.setAbove(current1);
					current1 = current1.getRight();
					current2 = current2.getRight();

				}

				if (k != h - 1){
					current1.setBelow(current2);
					current2.setAbove(current1);
					current1 = current1.getBelow();
				}

			}

			//if row number is odd
			else{

				for(int i=0; i<w-1; i++){

					current2 = current2.getLeft();

				}
				current2 = current2.getBelow();

				for(int i=0; i<w-1; i++){

					current2 = current2.getRight();

				}

				//creating vertical connections
				for(int j=0; j<w-1; j++){

					current1.setBelow(current2);
					current2.setAbove(current1);
					current1 = current1.getLeft();
					current2 = current2.getLeft();

				}

				if (k != h - 1){
					current1.setBelow(current2);
					current2.setAbove(current1);
					current1 = current1.getBelow();
				}

			}
		}
	}

	public int grid_height(){return h;}
	public int grid_width(){return w;}

	
	private MeshNode<E> validate(Position<E> p ) throws IllegalArgumentException{

		MeshNode<E> node = (MeshNode<E>) p; 
		return node;
	}

	public boolean isEmpty(){

		return ((h==0) && (w == 0));
	}

	private Position<E> position(MeshNode<E> node){
		return node;
	}

	public Position<E> leftPos(Position<E> p){
		 
		MeshNode<E> node = validate(p);
		return position(node.getLeft());


	} 

	public Position<E> rightPos(Position<E> p){
		 
		MeshNode<E> node = validate(p);
		return position(node.getRight());

	} 

	public Position<E> abovePos(Position<E> p){
		 
		MeshNode<E> node = validate(p);
		return position(node.getAbove());

	} 

	public Position<E> belowPos(Position<E> p){
		 
		MeshNode<E> node = validate(p);
		return position(node.getBelow());

	} 

	public E set(Position<E> p, E e)throws IllegalArgumentException{

		MeshNode<E> node = validate(p);
		E answer = node.getElement();
		node.setElement(e);
		return answer; 

	}

	//End of 1.1

	//function to get node from node number
	public Position<E> getNode(int nodeNum){

		head = new MeshNode<>();
		MeshNode<E> currentNode = head;
		int currentIter = 0;

		for(int j=0; j<h; j++){

			if(j%2 == 0){

				for (int i=0; i<w-1; i++){

					if (((j*w) + i) == nodeNum){return currentNode;}
					currentNode = currentNode.getRight();
					currentIter ++;

				}

				if((j+1)*(w-1) == nodeNum){return currentNode;}
				currentNode = currentNode.getBelow();
				currentIter ++;
			}

			else{

				for(int i=0; i<w-1; i++){

					if (((j*w) +i) == nodeNum){return currentNode;}
					currentNode = currentNode.getLeft();
					currentIter ++;
				}

				if((j+1)*(w-1) == nodeNum){return currentNode;}
				currentNode = currentNode.getBelow();
				currentIter ++;
			}
		}

		return currentNode;

	}

	private int currentNodeNumber = 0;
	private int currentPositionNumber = 0;

	//defining gridIterator class 
	private class gridIterator implements Iterator<E>{

		public boolean hasNext(){

			//traversing between rows and columns using curr and curr2
			MeshNode<E> curr;
			MeshNode<E> curr2;
			curr = head;
			curr2 = head;
			int k=0;

			while(k<currentNodeNumber){

				curr = curr.getRight();

				if(curr == null){

					curr2 = curr2.getBelow();
					curr = curr2;

				}

				k++;
			}

			return (curr.getRight() != null || curr.getBelow() != null);
		}

		//traversing between rows and columns to get the next element
		public E next() throws NoSuchElementException{

			MeshNode<E> curr;
			MeshNode<E> curr2;
			curr = head;
			curr2 = head;
			int k=0;

			while(k<currentNodeNumber){

				curr = curr.getRight();

				if(curr == null){

					curr2 = curr2.getBelow();
					curr = curr2;

				}

				k++;
			}

			// if there is an element to the right of curr return it
			if(curr.getRight()!=null) {

				return curr.getRight().getElement();
			}
			
			//if curr is at the rightmost end of any row return element below it
			else if(curr.getRight() == null && curr.getBelow()!=null) {

				curr2 = curr2.getBelow();
				curr = curr2;
				return curr.getElement();
			}

			//if curr is at the bottom left corner of the grid, there is no next element
			else if(curr.getRight()==null && curr.getBelow()==null){

				throw new NoSuchElementException("No such element");
			}

			return curr.getRight().getElement();
		}

		public void remove(){}
	}

	public Iterator<E> iterator(){

		Iterator<E> mygridIterator = new gridIterator();
		return mygridIterator;
	}

	//defining positionIterator class
	private class positionIterator implements Iterator<Position<E>>{

		public boolean hasNext(){

			MeshNode<E> curr;
			MeshNode<E> curr2;
			curr = head;
			curr2 = head;
			int k=0;

			while(k<currentNodeNumber){

				curr = curr.getRight();

				if(curr == null){

					curr2 = curr2.getBelow();
					curr = curr2;

				}

				k++;
			}

			return (curr.getRight() != null || curr.getBelow() != null);
		}

		//traversing between rows and columns to get the next element
		public Position<E> next() throws NoSuchElementException{

			MeshNode<E> curr;
			MeshNode<E> curr2;
			curr = head;
			curr2 = head;
			int k=0;

			while(k<currentNodeNumber){

				curr = curr.getRight();

				if(curr == null){

					curr2 = curr2.getBelow();
					curr = curr2;

				}

				k++;
			}

			// if there is an element to the right of curr return it
			if(curr.getRight()!=null) {

				return curr.getRight();
			}
			
			//if curr is at the rightmost end of any row return element below it
			else if(curr.getRight() == null && curr.getBelow()!=null) {

				curr2 = curr2.getBelow();
				curr = curr2;
				return curr;
			}

			//if curr is at the bottom left corner of the grid, there is no next element
			else if(curr.getRight()==null && curr.getBelow()==null){

				throw new NoSuchElementException ("Next element does not exist (end of grid)");
			}

			return curr.getRight();

		}

		public void remove(){}

	}

	public E getElementFromPosition(Position<E> p){

		MeshNode<E> node = validate(p);
		MeshNode<E> myNode;
		myNode = (MeshNode<E>) p;

		return myNode.getElement();
	}

	//creating the PositionIterable class
	private class PositionIterable implements Iterable<Position<E>>{

		//overwriting the iterator method
		public Iterator<Position<E>> iterator(){

			Iterator<Position<E>> myPositionIterator = new positionIterator();
			return myPositionIterator;
		}
	}

	public Iterable<Position<E>> position(){

		return new PositionIterable();
	}

	//defining the main function
	public static void main(String[] args){

		MeshGrid<Integer> myGrid = new MeshGrid<>(10,10);
		System.out.println("The Meshgrid has been created with the following dimensions:");
		System.out.println("Number of rows: " + myGrid.grid_height());
		System.out.println("Number of columns: " + myGrid.grid_width());

	}


}
